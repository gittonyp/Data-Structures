x=range(10)
for i in x:
    print(i+1)

